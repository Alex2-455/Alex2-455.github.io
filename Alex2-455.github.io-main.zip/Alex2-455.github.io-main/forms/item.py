from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField
from wtforms import BooleanField, SubmitField
from wtforms.validators import DataRequired


class ItemForm(FlaskForm):
    title = StringField('Заголовок и цена товара в формате: заголовок - цена₽', validators=[DataRequired()])

    content = TextAreaField("Содержание")
    is_private = BooleanField("Видно только авторизованным пользователям")
    submit = SubmitField('Применить')